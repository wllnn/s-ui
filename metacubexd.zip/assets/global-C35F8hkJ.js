import{T as a}from"./vendor-8-YBH5HO.js";import{ad as m}from"./index-DeJu0PyK.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
